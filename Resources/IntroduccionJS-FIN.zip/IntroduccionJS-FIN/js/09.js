// Arrays o Arreglos
const tecnologias = [20, 30, 40, true, "React.js"]

tecnologias[1]