let cliente = "Juan"
cliente = 30

let precio
precio = 1000
console.log(precio)