// Function Declaration

function sumar(numero1 = 0, numero2 = 0) {
    console.log(numero1 + numero2)
}


sumar(10, 20)
sumar(100, 131)
sumar(10)