const cliente = "Juan"
cliente = 30

const precio = 1000
console.log(precio)