// Evaluación de corto circuito

const auth = true
auth && console.log('Usuario Autenticado') 