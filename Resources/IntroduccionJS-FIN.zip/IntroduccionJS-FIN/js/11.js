const tecnologias = ['HTML', 'CSS', 'JavaScript', 'React.js', 'Node.js']

const react = tecnologias[3]

// Destructuring arrays
const [ , , , reactjs] = tecnologias

console.log(reactjs)