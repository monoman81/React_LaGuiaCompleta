export const sumar = (n1, n2) => n1 + n2

export const restar = (n1, n2) => n1 - n2

export const multiplicar = (n1, n2) =>  n1 * n2

export const division = (n1, n2)  => n1 / n2
