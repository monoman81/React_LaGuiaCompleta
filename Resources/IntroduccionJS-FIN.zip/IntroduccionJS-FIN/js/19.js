const numero1 = 20
const numero2 = 20

/*
    ==  (Comparador no estricto)
    === (Comparador estricto)
*/

if(numero1 === numero2) {
    console.log('Si, son iguales')
} else {
    console.log('No, no son iguales')
}