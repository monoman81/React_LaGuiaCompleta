// Condicionales
const disponible = 200
const retirar = 200

if(disponible >= retirar) {
    // Se cumple la condición
    console.log('Si puedes retirar')
} else {
    // no se cumple la condición
    console.log('Saldo insuficiente')
}

/**
 *  > Mayor que
 *  < Menor que
 *  >= Mayor o igual
 *  <= Menor o igual
 *  == igual
 *  === Igual estricto
 *  !== Diferente a
 */